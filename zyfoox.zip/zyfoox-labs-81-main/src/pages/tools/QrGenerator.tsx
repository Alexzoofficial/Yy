
import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import { QrCode, Download, RefreshCw } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Skeleton } from "@/components/ui/skeleton";

export default function QrGenerator() {
  const [content, setContent] = useState("");
  const [size, setSize] = useState("200");
  const [color, setColor] = useState("000000");
  const [backgroundColor, setBackgroundColor] = useState("FFFFFF");
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const { toast } = useToast();
  
  // Reset image loaded state when url changes
  useEffect(() => {
    setImageLoaded(false);
  }, [qrCodeUrl]);
  
  const handleGenerateQR = () => {
    if (!content.trim()) {
      toast({
        title: "Input required",
        description: "Please enter content for your QR code",
        variant: "destructive"
      });
      return;
    }
    
    setIsGenerating(true);
    setImageLoaded(false);
    
    // Using Google Chart API to generate QR code
    const url = `https://chart.googleapis.com/chart?cht=qr&chs=${size}x${size}&chl=${encodeURIComponent(content)}&chco=${color}&chf=bg,s,${backgroundColor}`;
    
    // Create an image object to verify the QR code loads correctly
    const img = new Image();
    img.onload = () => {
      setQrCodeUrl(url);
      setIsGenerating(false);
      toast({
        title: "QR Code Generated",
        description: "Your QR code has been created successfully"
      });
    };
    img.onerror = () => {
      setIsGenerating(false);
      toast({
        title: "Generation failed",
        description: "There was an error generating the QR code. Please try again with different parameters.",
        variant: "destructive"
      });
    };
    img.src = url;
  };
  
  const handleDownload = () => {
    if (!qrCodeUrl) return;
    
    const link = document.createElement("a");
    link.href = qrCodeUrl;
    link.download = `zyfoox-qrcode-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "QR Code Downloaded",
      description: "Your QR code has been downloaded successfully"
    });
  };
  
  const validateHexInput = (input: string) => {
    return input.replace(/[^0-9A-F]/ig, '').substring(0, 6);
  };

  return (
    <>
      <Helmet>
        <title>QR Code Generator - Free Online Tool | Zyfoox</title>
        <meta 
          name="description" 
          content="Create and customize QR codes for websites, text, phone numbers, and more in seconds with our free online QR code generator. No registration needed." 
        />
        <meta 
          name="keywords" 
          content="QR code generator, create QR code, QR code maker, free QR code, custom QR code, online QR generator, website QR code, URL QR code" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/qr-generator" />
      </Helmet>

      <ToolHero
        title="QR Code Generator"
        description="Create custom QR codes for websites, text, phone numbers, and more in seconds. Free online tool with no registration required."
        icon={<QrCode size={32} />}
      />

      <div className="container mx-auto max-w-4xl px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="glass-card rounded-xl p-6 animate-fade-in">
            <h2 className="text-xl font-semibold mb-4">Create Your QR Code</h2>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="content">Content (URL, text, etc.)</Label>
                <Input
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Enter URL or text for the QR code"
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label htmlFor="size">QR Code Size</Label>
                <Select value={size} onValueChange={setSize}>
                  <SelectTrigger id="size" className="mt-1">
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="100">Small (100x100)</SelectItem>
                    <SelectItem value="200">Medium (200x200)</SelectItem>
                    <SelectItem value="300">Large (300x300)</SelectItem>
                    <SelectItem value="400">Extra Large (400x400)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="color">QR Color</Label>
                  <div className="flex mt-1">
                    <Input
                      id="color"
                      type="color"
                      value={`#${color}`}
                      onChange={(e) => setColor(e.target.value.substring(1))}
                      className="w-12 p-1 h-10"
                    />
                    <Input
                      value={color}
                      onChange={(e) => setColor(validateHexInput(e.target.value))}
                      className="ml-2 flex-grow"
                      maxLength={6}
                      placeholder="Color hex"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="bgcolor">Background Color</Label>
                  <div className="flex mt-1">
                    <Input
                      id="bgcolor"
                      type="color"
                      value={`#${backgroundColor}`}
                      onChange={(e) => setBackgroundColor(e.target.value.substring(1))}
                      className="w-12 p-1 h-10"
                    />
                    <Input
                      value={backgroundColor}
                      onChange={(e) => setBackgroundColor(validateHexInput(e.target.value))}
                      className="ml-2 flex-grow"
                      maxLength={6}
                      placeholder="Background hex"
                    />
                  </div>
                </div>
              </div>
              
              <Button 
                onClick={handleGenerateQR} 
                disabled={!content.trim() || isGenerating}
                className="w-full mt-4"
              >
                {isGenerating ? (
                  <>
                    <LoadingSpinner size="sm" className="mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    <RefreshCw size={18} className="mr-2" />
                    Generate QR Code
                  </>
                )}
              </Button>
            </div>
          </div>
          
          <div className="glass-card rounded-xl p-6 animate-fade-in animate-delay-100 flex flex-col items-center justify-center">
            {qrCodeUrl ? (
              <>
                <div className="mb-4 p-4 bg-white rounded-lg relative">
                  {!imageLoaded && (
                    <div className="absolute inset-0 flex items-center justify-center bg-white/80 rounded-lg">
                      <LoadingSpinner size="lg" />
                    </div>
                  )}
                  <img 
                    src={qrCodeUrl} 
                    alt="Generated QR Code" 
                    className={`mx-auto ${imageLoaded ? '' : 'opacity-0'}`}
                    loading="lazy"
                    onLoad={() => setImageLoaded(true)}
                  />
                </div>
                <Button 
                  onClick={handleDownload} 
                  className="mt-4"
                  disabled={!imageLoaded}
                >
                  <Download size={18} className="mr-2" />
                  Download QR Code
                </Button>
              </>
            ) : (
              <div className="text-center text-muted-foreground">
                <QrCode size={100} className="mx-auto opacity-20 mb-4" />
                <p>Your QR code will appear here</p>
              </div>
            )}
          </div>
        </div>
        
        <div className="glass-card rounded-xl p-6 mt-8 animate-fade-in">
          <h2 className="text-2xl font-bold mb-4">What is a QR Code?</h2>
          <p className="text-muted-foreground mb-6">
            QR (Quick Response) codes are two-dimensional barcodes that can be scanned using smartphone cameras to quickly access
            information, websites, or trigger specific actions. They're widely used for marketing, payments, ticketing, and more.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="p-4 bg-secondary rounded-lg">
              <h3 className="font-semibold mb-2">Business Uses</h3>
              <p className="text-sm text-muted-foreground">
                Add QR codes to business cards, product packaging, and promotional materials to connect customers with your online presence.
              </p>
            </div>
            <div className="p-4 bg-secondary rounded-lg">
              <h3 className="font-semibold mb-2">Digital Payments</h3>
              <p className="text-sm text-muted-foreground">
                Generate QR codes for payment information to enable contactless transactions for your business or personal use.
              </p>
            </div>
            <div className="p-4 bg-secondary rounded-lg">
              <h3 className="font-semibold mb-2">Event Management</h3>
              <p className="text-sm text-muted-foreground">
                Create QR codes for event tickets, venue information, or digital programs to enhance attendee experience.
              </p>
            </div>
          </div>
          
          <h3 className="text-xl font-semibold mb-3">How to Use QR Codes Effectively</h3>
          <p className="text-muted-foreground mb-4">
            For maximum scanning reliability, ensure there's good contrast between your QR code's foreground and background colors.
            Always test your QR codes on multiple devices before publishing. Consider adding a logo or call-to-action near your QR code
            to encourage scanning.
          </p>
          <p className="text-muted-foreground">
            The QR codes generated by this tool are static, meaning the encoded information cannot be changed after creation.
            They're perfect for encoding fixed information like website URLs, contact details, or plain text messages.
          </p>
        </div>
      </div>
    </>
  );
}
