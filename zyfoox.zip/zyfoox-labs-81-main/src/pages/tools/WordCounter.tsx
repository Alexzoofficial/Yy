
import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import { FileText } from "lucide-react";

export default function WordCounter() {
  const [text, setText] = useState("");
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const [charNoSpaceCount, setCharNoSpaceCount] = useState(0);
  const [sentenceCount, setSentenceCount] = useState(0);
  const [paragraphCount, setParagraphCount] = useState(0);
  const [readingTime, setReadingTime] = useState(0);

  useEffect(() => {
    // Count words
    const words = text.trim().split(/\s+/).filter(word => word.length > 0);
    setWordCount(words.length);
    
    // Count characters
    setCharCount(text.length);
    
    // Count characters without spaces
    setCharNoSpaceCount(text.replace(/\s/g, "").length);
    
    // Count sentences (simple approximation)
    const sentences = text.split(/[.!?]+/).filter(sentence => sentence.trim().length > 0);
    setSentenceCount(sentences.length);
    
    // Count paragraphs
    const paragraphs = text.split(/\n+/).filter(paragraph => paragraph.trim().length > 0);
    setParagraphCount(paragraphs.length);
    
    // Calculate reading time (avg reading speed: 225 words per minute)
    setReadingTime(Math.ceil(words.length / 225));
  }, [text]);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const clearText = () => {
    setText("");
  };

  return (
    <>
      <Helmet>
        <title>Word Counter - Zyfoox</title>
        <meta 
          name="description" 
          content="Count words, characters, sentences, and paragraphs in your text with reading time estimates. Free online word counter tool." 
        />
        <meta 
          name="keywords" 
          content="word counter, character counter, text counter, word count tool, character count tool, reading time calculator" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/word-counter" />
      </Helmet>

      <ToolHero
        title="Word Counter"
        description="Count words, characters, sentences, and paragraphs in your text with reading time estimates."
        icon={<FileText size={32} />}
      />

      <div className="container mx-auto max-w-4xl px-4 py-8">
        <div className="glass-card rounded-xl p-6 animate-fade-in mb-6">
          <div className="mb-4 flex justify-between items-center">
            <h2 className="text-xl font-semibold">Enter Your Text</h2>
            <button
              onClick={clearText}
              className="text-sm px-3 py-1 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors"
            >
              Clear All
            </button>
          </div>
          
          <textarea
            value={text}
            onChange={handleTextChange}
            placeholder="Type or paste your text here..."
            className="w-full h-64 p-4 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-1 focus:ring-primary focus:outline-none bg-card/50 resize-y text-base"
          ></textarea>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
          <div className="glass-card rounded-xl p-4 animate-fade-in animate-delay-100 text-center">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Words</h3>
            <p className="text-3xl font-bold">{wordCount}</p>
          </div>
          
          <div className="glass-card rounded-xl p-4 animate-fade-in animate-delay-200 text-center">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Characters</h3>
            <p className="text-3xl font-bold">{charCount}</p>
          </div>
          
          <div className="glass-card rounded-xl p-4 animate-fade-in animate-delay-300 text-center">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Characters (no spaces)</h3>
            <p className="text-3xl font-bold">{charNoSpaceCount}</p>
          </div>
          
          <div className="glass-card rounded-xl p-4 animate-fade-in animate-delay-400 text-center">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Sentences</h3>
            <p className="text-3xl font-bold">{sentenceCount}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="glass-card rounded-xl p-4 animate-fade-in animate-delay-500 text-center">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Paragraphs</h3>
            <p className="text-3xl font-bold">{paragraphCount}</p>
          </div>
          
          <div className="glass-card rounded-xl p-4 animate-fade-in animate-delay-600 text-center">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Reading Time</h3>
            <p className="text-3xl font-bold">{readingTime} min</p>
          </div>
        </div>
      </div>
    </>
  );
}
