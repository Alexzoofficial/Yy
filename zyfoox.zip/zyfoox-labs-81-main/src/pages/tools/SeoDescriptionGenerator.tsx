
import { useState } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import ToolInterface from "@/components/tools/ToolInterface";
import { FileEdit } from "lucide-react";

export default function SeoDescriptionGenerator() {
  // Function to generate SEO descriptions
  const generateSeoDescriptions = async (formData: Record<string, string>) => {
    try {
      const { title, keywords, contentType, targetAudience, tone } = formData;
      
      // In a production app, this would call an AI service API
      // For demo purposes, we'll use templates with variations
      
      const keywordsList = keywords.split(',').map(k => k.trim()).filter(k => k.length > 0);
      const primaryKeyword = keywordsList[0] || "";
      const secondaryKeywords = keywordsList.slice(1, 3);
      
      // Create different template variations
      const templates = [
        `Discover how to master ${primaryKeyword} with our comprehensive ${contentType}. Perfect for ${targetAudience} looking to improve their results. Learn about ${secondaryKeywords.join(' and ')} today.`,
        
        `Looking for effective ${primaryKeyword} strategies? Our ${contentType} provides expert insights for ${targetAudience}. Explore ${secondaryKeywords.join(', ')} and more.`,
        
        `Transform your approach to ${primaryKeyword} with this essential ${contentType}. Designed specifically for ${targetAudience} who want to achieve better outcomes. Includes ${secondaryKeywords.join(' & ')}.`,
        
        `Struggling with ${primaryKeyword}? This ${contentType} offers proven solutions for ${targetAudience}. Get actionable advice on ${secondaryKeywords.join(', ')} and start seeing results.`,
        
        `Master the art of ${primaryKeyword} with expert tips in our latest ${contentType}. Ideal for ${targetAudience} seeking professional guidance. Covers ${secondaryKeywords.join(' and ')} in detail.`,
        
        `Unlock the secrets of successful ${primaryKeyword} with this ${tone} ${contentType}. Created for ${targetAudience} who need practical solutions. Features insights on ${secondaryKeywords.join(' & ')}.`,
        
        `Want to excel at ${primaryKeyword}? Our comprehensive ${contentType} walks ${targetAudience} through everything they need to know, including ${secondaryKeywords.join(' and ')}.`,
        
        `Dive into the world of ${primaryKeyword} with our ${tone} ${contentType}. Perfect for ${targetAudience} looking to stay ahead of the competition. Explore ${secondaryKeywords.join(', ')} and more.`,
        
        `Boost your ${primaryKeyword} results with this actionable ${contentType}. Tailored for ${targetAudience} who want real-world strategies that work. Includes ${secondaryKeywords.join(' & ')}.`,
        
        `The ultimate guide to ${primaryKeyword} for ${targetAudience}. This ${tone} ${contentType} covers everything from ${secondaryKeywords.join(' to ')} and beyond.`
      ];
      
      // Create variations based on the title if available
      if (title) {
        templates.push(
          `${title}: Learn everything about ${primaryKeyword} in our comprehensive ${contentType} for ${targetAudience}. Includes ${secondaryKeywords.join(' and ')}.`,
          
          `${title} - The definitive ${contentType} on ${primaryKeyword} for ${targetAudience}. Discover strategies for ${secondaryKeywords.join(' and ')} that deliver results.`,
          
          `${title}: A ${tone} approach to ${primaryKeyword} specifically designed for ${targetAudience}. Master ${secondaryKeywords.join(' & ')} and more.`
        );
      }
      
      // Format the output
      let result = `# SEO Meta Description Suggestions\n\n`;
      
      if (title) {
        result += `Page Title: "${title}"\n`;
      }
      
      result += `Primary Keyword: ${primaryKeyword}\n`;
      result += `Content Type: ${contentType}\n`;
      result += `Target Audience: ${targetAudience}\n`;
      result += `Tone: ${tone}\n\n`;
      
      result += `## Description Options\n\n`;
      
      templates.forEach((description, index) => {
        // Make sure description doesn't exceed 160 characters
        let finalDescription = description;
        if (description.length > 160) {
          finalDescription = description.substring(0, 157) + '...';
        }
        
        const length = finalDescription.length;
        const lengthStatus = length > 160 ? "❌ Too long" : length < 70 ? "⚠️ Too short" : "✅ Optimal length";
        
        result += `### Option ${index + 1}\n\n`;
        result += `"${finalDescription}"\n\n`;
        result += `**Character Count:** ${length} (${lengthStatus})\n\n`;
        
        // Add random effectiveness score and tips
        const score = Math.floor(Math.random() * 30) + 70; // Score between 70-100
        result += `**Effectiveness Score:** ${score}/100\n\n`;
        
        result += `**Analysis:**\n`;
        if (length > 160) {
          result += `- Too long for search engine display, will be truncated\n`;
        } else if (length < 70) {
          result += `- Could be more descriptive and make better use of available space\n`;
        } else {
          result += `- Good length for search engine display\n`;
        }
        
        // Check for keyword inclusion
        if (description.toLowerCase().includes(primaryKeyword.toLowerCase())) {
          result += `- ✅ Includes primary keyword\n`;
        } else {
          result += `- ❌ Missing primary keyword\n`;
        }
        
        let secondaryKeywordCount = 0;
        secondaryKeywords.forEach(keyword => {
          if (description.toLowerCase().includes(keyword.toLowerCase())) {
            secondaryKeywordCount++;
          }
        });
        
        if (secondaryKeywordCount > 0) {
          result += `- ✅ Includes ${secondaryKeywordCount} secondary keywords\n`;
        }
        
        // Add random tips
        const tips = [
          `- Creates a clear value proposition for the reader`,
          `- Contains a subtle call-to-action`,
          `- Matches the specified ${tone} tone well`,
          `- Specifically addresses the target audience of ${targetAudience}`,
          `- Highlights the content format (${contentType}) clearly`,
          `- Uses action verbs that encourage clicks`,
          `- Has a good balance of keywords and natural language`,
          `- Creates curiosity to drive click-through`
        ];
        
        // Pick 2-3 random tips
        const selectedTips = [];
        for (let i = 0; i < 2; i++) {
          const randomTip = tips[Math.floor(Math.random() * tips.length)];
          if (!selectedTips.includes(randomTip)) {
            selectedTips.push(randomTip);
          }
        }
        
        result += selectedTips.join('\n');
        result += '\n\n';
      });
      
      result += `## Best Practices for Meta Descriptions\n\n`;
      result += `1. Keep descriptions between 140-160 characters to prevent truncation\n`;
      result += `2. Include your primary keyword naturally (not forced)\n`;
      result += `3. Write compelling copy that encourages clicks\n`;
      result += `4. Include a clear value proposition or benefit\n`;
      result += `5. Add a subtle call-to-action where appropriate\n`;
      result += `6. Ensure the description accurately reflects the page content\n`;
      result += `7. Make each description unique across your website\n`;
      result += `8. Consider including structured data for rich snippets\n`;
      
      return result;
    } catch (error) {
      console.error("Error generating SEO descriptions:", error);
      return "An error occurred while generating SEO descriptions. Please try again.";
    }
  };

  // Define the fields for the tool interface
  const fields = [
    {
      id: "title",
      label: "Page Title (Optional)",
      type: "text" as const,
      placeholder: "E.g., 10 Proven Content Marketing Strategies for 2023"
    },
    {
      id: "keywords",
      label: "Keywords (Comma Separated)",
      type: "text" as const,
      placeholder: "E.g., content marketing, digital strategy, SEO"
    },
    {
      id: "contentType",
      label: "Content Type",
      type: "select" as const,
      placeholder: "Select content type",
      options: [
        { value: "article", label: "Article" },
        { value: "blog post", label: "Blog Post" },
        { value: "product page", label: "Product Page" },
        { value: "landing page", label: "Landing Page" },
        { value: "guide", label: "Guide" },
        { value: "tutorial", label: "Tutorial" },
        { value: "case study", label: "Case Study" },
        { value: "review", label: "Review" },
        { value: "service page", label: "Service Page" },
        { value: "video", label: "Video" }
      ]
    },
    {
      id: "targetAudience",
      label: "Target Audience",
      type: "text" as const,
      placeholder: "E.g., small business owners, marketing professionals, students"
    },
    {
      id: "tone",
      label: "Tone of Voice",
      type: "select" as const,
      placeholder: "Select tone",
      options: [
        { value: "professional", label: "Professional" },
        { value: "conversational", label: "Conversational" },
        { value: "authoritative", label: "Authoritative" },
        { value: "friendly", label: "Friendly" },
        { value: "educational", label: "Educational" },
        { value: "persuasive", label: "Persuasive" },
        { value: "enthusiastic", label: "Enthusiastic" },
        { value: "technical", label: "Technical" }
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>SEO Description Generator - Zyfoox</title>
        <meta 
          name="description" 
          content="Create compelling meta descriptions that increase click-through rates from search results. Free online SEO description generator." 
        />
        <meta 
          name="keywords" 
          content="SEO description generator, meta description creator, SEO meta tag generator, description tag generator, SEO copywriting tool" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/seo-description-generator" />
      </Helmet>

      <ToolHero
        title="SEO Description Generator"
        description="Create compelling meta descriptions that increase click-through rates from search results."
        icon={<FileEdit size={32} />}
      />

      <ToolInterface
        toolName="SEO Description Generator"
        fields={fields}
        generateFunction={generateSeoDescriptions}
      />
    </>
  );
}
