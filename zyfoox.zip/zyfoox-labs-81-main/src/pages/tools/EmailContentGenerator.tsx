
import { useState } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import ToolInterface from "@/components/tools/ToolInterface";
import { Mail } from "lucide-react";

export default function EmailContentGenerator() {
  // Function to generate email content
  const generateEmailContent = async (formData: Record<string, string>) => {
    try {
      const { emailType, industry, tone, audience, productName, keyPoints } = formData;
      
      // Simulated API response (in a real app, this would come from an API)
      let result = `# ${emailType} Email Template\n\n`;
      
      // Add email metadata
      result += `**Industry:** ${industry}\n`;
      result += `**Tone:** ${tone}\n`;
      result += `**Target Audience:** ${audience}\n`;
      result += `**Product/Service:** ${productName || "Not specified"}\n\n`;
      
      // Generate subject lines
      result += `## Subject Line Options\n\n`;
      
      const subjectLines = generateSubjectLines(emailType, productName, audience, industry);
      subjectLines.forEach((subject, index) => {
        result += `${index + 1}. ${subject}\n`;
      });
      
      // Generate email body
      result += `\n## Email Body\n\n`;
      
      // Generate salutation
      const salutations = [
        "Hi there,",
        `Hello ${audience} professional,`,
        "Greetings,",
        "Dear valued subscriber,",
        `Hi ${audience} enthusiast,`
      ];
      const salutation = salutations[Math.floor(Math.random() * salutations.length)];
      result += `${salutation}\n\n`;
      
      // Generate opening based on email type
      result += generateOpening(emailType, tone, audience, productName, industry);
      
      // Generate body paragraphs
      const keyPointsList = keyPoints ? keyPoints.split(',').map(point => point.trim()).filter(point => point.length > 0) : [];
      result += generateBodyContent(emailType, tone, keyPointsList, productName, audience);
      
      // Generate closing
      result += generateClosing(emailType, tone);
      
      // Generate signature
      result += `\nBest regards,\n`;
      result += `[Your Name]\n`;
      result += `[Your Position]\n`;
      result += `[Your Company]\n`;
      result += `[Contact Information]\n\n`;
      
      // Generate tips
      result += `## Email Marketing Tips\n\n`;
      result += `- **Personalization:** Consider adding personalization tokens like {first_name} to increase open rates.\n`;
      result += `- **Mobile Optimization:** Ensure your email displays correctly on mobile devices.\n`;
      result += `- **A/B Testing:** Test different subject lines to see which generates higher open rates.\n`;
      result += `- **CTA Placement:** Place your main call-to-action above the fold for better visibility.\n`;
      result += `- **Preview Text:** Don't forget to optimize your preview text to complement your subject line.\n`;
      
      return result;
    } catch (error) {
      console.error("Error generating email content:", error);
      return "An error occurred while generating email content. Please try again.";
    }
  };
  
  // Helper function to generate subject lines
  const generateSubjectLines = (emailType: string, productName: string, audience: string, industry: string) => {
    const subjectLines = [];
    
    switch (emailType) {
      case "Welcome":
        subjectLines.push(
          `Welcome to ${productName || "our community"} - Here's what's next`,
          `Thanks for joining ${productName || "us"} - Get started here`,
          `Welcome aboard! Your guide to ${productName || industry}`,
          `You're in! Start your ${industry} journey today`,
          `Welcome to the ${productName || industry} family!`
        );
        break;
      case "Newsletter":
        subjectLines.push(
          `${industry} insights you don't want to miss this month`,
          `The latest in ${industry}: Updates, tips, and trends`,
          `[New Issue] ${industry} Newsletter - What's trending now`,
          `Your monthly ${industry} digest is here`,
          `Inside look: ${industry} news and insights`
        );
        break;
      case "Promotional":
        subjectLines.push(
          `Special offer: ${productName || "Our services"} at 30% off - Limited time`,
          `Don't miss out: Exclusive deal for ${audience}`,
          `Unlock premium ${industry} benefits today`,
          `Limited offer for ${audience} professionals`,
          `The ${productName} deal you've been waiting for`
        );
        break;
      case "Follow-up":
        subjectLines.push(
          `Following up on our conversation about ${productName || industry}`,
          `Quick check-in regarding ${productName || "our services"}`,
          `Next steps for your ${industry} journey`,
          `Let's continue our ${industry} conversation`,
          `Important follow-up: Your ${productName || industry} inquiry`
        );
        break;
      default:
        subjectLines.push(
          `Important update from ${productName || "our team"}`,
          `${industry} insights for ${audience}`,
          `Discover what's new in ${industry}`,
          `A special message for our ${audience} community`,
          `Your ${industry} journey starts here`
        );
    }
    
    return subjectLines;
  };
  
  // Helper function to generate email opening
  const generateOpening = (emailType: string, tone: string, audience: string, productName: string, industry: string) => {
    let opening = "";
    
    switch (emailType) {
      case "Welcome":
        opening = `Thank you for joining ${productName || "our community"}! We're thrilled to have you with us and can't wait to help you achieve your ${industry} goals. As a valued member of our ${audience} community, you now have access to exclusive resources designed specifically for professionals like you.\n\n`;
        break;
      case "Newsletter":
        opening = `We're back with another edition of our ${industry} newsletter, packed with valuable insights and updates to keep you at the forefront of the industry. This month's edition brings you the latest trends, expert tips, and success stories from the world of ${industry}.\n\n`;
        break;
      case "Promotional":
        opening = `We're excited to bring you an exclusive offer that we've crafted specifically for our ${audience} community. For a limited time, we're offering special access to ${productName || "our premium services"} with benefits that will transform your ${industry} experience.\n\n`;
        break;
      case "Follow-up":
        opening = `I hope this email finds you well. I wanted to follow up on our previous conversation about ${productName || industry} and see if you have any questions or if there's anything I can help you with moving forward.\n\n`;
        break;
      default:
        opening = `I hope you're having a great day. I'm reaching out to share some important information about ${productName || industry} that I believe will be valuable for ${audience} professionals like yourself.\n\n`;
    }
    
    // Adjust tone
    if (tone === "Professional") {
      // Already professional, no change needed
    } else if (tone === "Casual") {
      opening = opening.replace("I hope this email finds you well", "Hope you're doing great");
      opening = opening.replace("wanted to follow up", "just checking in");
      opening = opening.replace("I'm reaching out", "I'm dropping you a line");
    } else if (tone === "Enthusiastic") {
      opening = opening.replace("We're thrilled", "We're SUPER excited");
      opening = opening.replace("excited to bring", "absolutely delighted to bring");
      opening = opening + "This is going to be amazing! 🎉\n\n";
    }
    
    return opening;
  };
  
  // Helper function to generate email body content
  const generateBodyContent = (emailType: string, tone: string, keyPoints: string[], productName: string, audience: string) => {
    let body = "";
    
    // If key points were provided, use them
    if (keyPoints.length > 0) {
      body += `Here are the key points you should know:\n\n`;
      keyPoints.forEach(point => {
        body += `- **${point}**: `;
        
        // Generate a short explanation for each point
        const explanations = [
          `This will help you maximize your results and achieve better outcomes.`,
          `We've seen tremendous success with this approach among our ${audience} clients.`,
          `This is a game-changer that can significantly improve your experience.`,
          `This feature has been specifically designed based on feedback from ${audience} professionals.`,
          `Our research shows this is critical for success in this area.`
        ];
        body += explanations[Math.floor(Math.random() * explanations.length)] + "\n";
      });
      body += "\n";
    } else {
      // Default content based on email type
      switch (emailType) {
        case "Welcome":
          body += `**Here's what you can expect:**\n\n`;
          body += `- **Resource Library**: Access to our exclusive guides, templates, and tools\n`;
          body += `- **Community Access**: Connect with like-minded ${audience} professionals\n`;
          body += `- **Priority Support**: Get your questions answered by our expert team\n`;
          body += `- **Regular Updates**: Stay informed with the latest ${productName || "industry"} news\n\n`;
          
          body += `To get started, simply login to your account and complete your profile. This will help us personalize your experience and provide recommendations tailored to your specific needs.\n\n`;
          break;
          
        case "Newsletter":
          body += `**This Month's Highlights:**\n\n`;
          body += `- **Industry Trends**: The top 3 emerging trends in ${productName || "the industry"} and how they affect you\n`;
          body += `- **Success Story**: How a ${audience} professional increased their results by 45% using our methodology\n`;
          body += `- **Expert Interview**: Insights from industry leader on the future of ${productName || "the field"}\n`;
          body += `- **Upcoming Events**: Mark your calendar for these must-attend webinars and conferences\n\n`;
          
          body += `We've also included some exclusive tips and tricks that you can implement right away to improve your results.\n\n`;
          break;
          
        case "Promotional":
          body += `**Here's what our special offer includes:**\n\n`;
          body += `- **30% Discount**: Exclusive pricing for our valued subscribers\n`;
          body += `- **Extended Access**: Get 3 additional months of premium features\n`;
          body += `- **Priority Support**: Skip the queue and get immediate assistance\n`;
          body += `- **Free Training Session**: One-on-one guidance from our expert team\n\n`;
          
          body += `This offer is only available until [DATE], so don't miss your chance to take advantage of these exceptional benefits.\n\n`;
          break;
          
        case "Follow-up":
          body += `I wanted to address any questions you might have about ${productName || "our services"} and provide some additional information that might be helpful in your decision-making process.\n\n`;
          body += `Based on our previous conversation, I thought these points might interest you:\n\n`;
          body += `- Our solution has helped ${audience} professionals increase their efficiency by an average of 27%\n`;
          body += `- We offer a tailored onboarding process to ensure a smooth transition\n`;
          body += `- Our customer success team provides ongoing support to maximize your results\n\n`;
          
          body += `I'd be happy to schedule a follow-up call to discuss these points in more detail and address any specific concerns you might have.\n\n`;
          break;
          
        default:
          body += `We believe that ${productName || "our solution"} can make a significant difference for ${audience} professionals like yourself. Our approach is designed to address the unique challenges you face and provide effective solutions that deliver measurable results.\n\n`;
          body += `We've worked with numerous clients in your position and have consistently helped them achieve their goals through our proven methodology.\n\n`;
      }
    }
    
    // Add a call to action
    body += generateCallToAction(emailType, productName);
    
    // Adjust tone
    if (tone === "Professional") {
      // Already professional, no change needed
    } else if (tone === "Casual") {
      body = body.replace("I wanted to address", "I wanted to clear up");
      body = body.replace("decision-making process", "decision");
      body = body.replace("schedule a follow-up call", "jump on a quick call");
    } else if (tone === "Enthusiastic") {
      body = body.replace("can make a significant difference", "can TRANSFORM your approach");
      body = body.replace("measurable results", "AMAZING results");
      body = body + "We're incredibly excited about the possibilities! 🚀\n\n";
    }
    
    return body;
  };
  
  // Helper function to generate call to action
  const generateCallToAction = (emailType: string, productName: string) => {
    let cta = "";
    
    switch (emailType) {
      case "Welcome":
        cta = `**[Complete Your Profile Now]**\n\n`;
        break;
      case "Newsletter":
        cta = `**[Read the Full Articles on Our Website]**\n\n`;
        break;
      case "Promotional":
        cta = `**[Claim Your 30% Discount Now]**\n\n`;
        break;
      case "Follow-up":
        cta = `**[Schedule a Call with Our Team]**\n\n`;
        break;
      default:
        cta = `**[Learn More About ${productName || "Our Services"}]**\n\n`;
    }
    
    return cta;
  };
  
  // Helper function to generate email closing
  const generateClosing = (emailType: string, tone: string) => {
    let closing = "";
    
    switch (emailType) {
      case "Welcome":
        closing = `We're here to support you every step of the way. If you have any questions, don't hesitate to reach out to our support team.\n\n`;
        break;
      case "Newsletter":
        closing = `Thank you for being a valued subscriber. We look forward to bringing you more insights next month.\n\n`;
        break;
      case "Promotional":
        closing = `Remember, this offer expires soon. We look forward to helping you take your experience to the next level.\n\n`;
        break;
      case "Follow-up":
        closing = `I value your time and appreciate your consideration. I'm looking forward to your response and the opportunity to continue our conversation.\n\n`;
        break;
      default:
        closing = `Thank you for your attention. We're committed to your success and look forward to the opportunity to work together.\n\n`;
    }
    
    // Adjust tone
    if (tone === "Professional") {
      // Already professional, no change needed
    } else if (tone === "Casual") {
      closing = closing.replace("don't hesitate to reach out", "just give us a shout");
      closing = closing.replace("I value your time", "Thanks for your time");
    } else if (tone === "Enthusiastic") {
      closing = closing.replace("We're here to support you", "We're THRILLED to support you");
      closing = closing.replace("look forward to", "can't WAIT to");
    }
    
    return closing;
  };

  // Define the fields for the tool interface
  const fields = [
    {
      id: "emailType",
      label: "Email Type",
      type: "select" as const,
      placeholder: "Select email type",
      options: [
        { value: "Welcome", label: "Welcome Email" },
        { value: "Newsletter", label: "Newsletter" },
        { value: "Promotional", label: "Promotional Email" },
        { value: "Follow-up", label: "Follow-up Email" },
        { value: "General", label: "General Communication" }
      ]
    },
    {
      id: "industry",
      label: "Industry/Niche",
      type: "text" as const,
      placeholder: "E.g., Technology, Healthcare, Finance, Education"
    },
    {
      id: "tone",
      label: "Tone",
      type: "select" as const,
      placeholder: "Select tone",
      options: [
        { value: "Professional", label: "Professional" },
        { value: "Casual", label: "Casual" },
        { value: "Enthusiastic", label: "Enthusiastic" }
      ]
    },
    {
      id: "audience",
      label: "Target Audience",
      type: "text" as const,
      placeholder: "E.g., Marketing Professionals, Small Business Owners, HR Managers"
    },
    {
      id: "productName",
      label: "Product/Service Name (Optional)",
      type: "text" as const,
      placeholder: "Name of your product or service"
    },
    {
      id: "keyPoints",
      label: "Key Points (Optional, comma separated)",
      type: "textarea" as const,
      placeholder: "E.g., New features, Benefits, Special offers"
    }
  ];

  return (
    <>
      <Helmet>
        <title>Email Content Generator - Zyfoox</title>
        <meta 
          name="description" 
          content="Generate professional email content for marketing, outreach, follow-ups, and more. Free online email template generator." 
        />
        <meta 
          name="keywords" 
          content="email content generator, email template generator, marketing email creator, professional email writer, business email generator" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/email-content-generator" />
      </Helmet>

      <ToolHero
        title="Email Content Generator"
        description="Generate professional email content for marketing, outreach, follow-ups, and more."
        icon={<Mail size={32} />}
      />

      <ToolInterface
        toolName="Email Content Generator"
        fields={fields}
        generateFunction={generateEmailContent}
      />
    </>
  );
}
