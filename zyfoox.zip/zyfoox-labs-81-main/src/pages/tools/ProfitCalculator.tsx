
import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import ToolHero from "@/components/tools/ToolHero";
import { PieChart } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function ProfitCalculator() {
  const [costPrice, setCostPrice] = useState(100);
  const [sellingPrice, setSellingPrice] = useState(150);
  const [quantity, setQuantity] = useState(1);
  
  // Calculated values
  const [profit, setProfit] = useState(0);
  const [profitMargin, setProfitMargin] = useState(0);
  const [markupPercentage, setMarkupPercentage] = useState(0);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [totalCost, setTotalCost] = useState(0);
  const [totalProfit, setTotalProfit] = useState(0);

  useEffect(() => {
    // Calculate single unit profit
    const profitPerUnit = sellingPrice - costPrice;
    setProfit(profitPerUnit);
    
    // Calculate profit margin (profit / selling price)
    const margin = sellingPrice > 0 ? (profitPerUnit / sellingPrice) * 100 : 0;
    setProfitMargin(margin);
    
    // Calculate markup (profit / cost price)
    const markup = costPrice > 0 ? (profitPerUnit / costPrice) * 100 : 0;
    setMarkupPercentage(markup);
    
    // Calculate totals
    setTotalRevenue(sellingPrice * quantity);
    setTotalCost(costPrice * quantity);
    setTotalProfit(profitPerUnit * quantity);
  }, [costPrice, sellingPrice, quantity]);

  const handleCostPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value) || 0;
    setCostPrice(value);
  };

  const handleSellingPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value) || 0;
    setSellingPrice(value);
  };

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value) || 0;
    setQuantity(value > 0 ? value : 1); // Ensure minimum of 1
  };

  return (
    <>
      <Helmet>
        <title>Profit Calculator - Zyfoox</title>
        <meta 
          name="description" 
          content="Calculate profit margins, markup, revenue, and other key business financial metrics. Free online profit calculator." 
        />
        <meta 
          name="keywords" 
          content="profit calculator, margin calculator, markup calculator, business calculator, revenue calculator" 
        />
        <link rel="canonical" href="https://zyfoox.com/tools/profit-calculator" />
      </Helmet>

      <ToolHero
        title="Profit Calculator"
        description="Calculate profit margins, markup, revenue, and other key business financial metrics."
        icon={<PieChart size={32} />}
      />

      <div className="container mx-auto max-w-4xl px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="glass-card rounded-xl p-6 animate-fade-in">
            <h2 className="text-xl font-semibold mb-4">Enter Values</h2>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="cost-price">Cost Price (per unit)</Label>
                <div className="relative mt-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-muted-foreground">$</span>
                  </div>
                  <Input
                    id="cost-price"
                    type="number"
                    value={costPrice}
                    onChange={handleCostPriceChange}
                    className="pl-8"
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="selling-price">Selling Price (per unit)</Label>
                <div className="relative mt-1">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-muted-foreground">$</span>
                  </div>
                  <Input
                    id="selling-price"
                    type="number"
                    value={sellingPrice}
                    onChange={handleSellingPriceChange}
                    className="pl-8"
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="quantity">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={quantity}
                  onChange={handleQuantityChange}
                  className="mt-1"
                  min="1"
                />
              </div>
            </div>
          </div>
          
          <div className="glass-card rounded-xl p-6 animate-fade-in animate-delay-100">
            <h2 className="text-xl font-semibold mb-4">Results</h2>
            
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-primary/10 rounded-lg p-4 text-center">
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Profit (per unit)</h3>
                  <p className={`text-xl font-semibold ${profit < 0 ? 'text-red-500' : 'text-green-500'}`}>
                    ${profit.toFixed(2)}
                  </p>
                </div>
                
                <div className="bg-primary/10 rounded-lg p-4 text-center">
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">Profit Margin</h3>
                  <p className={`text-xl font-semibold ${profitMargin < 0 ? 'text-red-500' : 'text-green-500'}`}>
                    {profitMargin.toFixed(2)}%
                  </p>
                </div>
              </div>
              
              <div className="bg-secondary/20 rounded-lg p-4">
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">Markup Percentage</span>
                  <span className={`font-semibold ${markupPercentage < 0 ? 'text-red-500' : ''}`}>
                    {markupPercentage.toFixed(2)}%
                  </span>
                </div>
                
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">Revenue (Total)</span>
                  <span className="font-semibold">${totalRevenue.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">Cost (Total)</span>
                  <span className="font-semibold">${totalCost.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Profit (Total)</span>
                  <span className={`font-semibold ${totalProfit < 0 ? 'text-red-500' : 'text-green-500'}`}>
                    ${totalProfit.toFixed(2)}
                  </span>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-secondary/30 to-primary/30 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">Breakdown</h3>
                
                {totalRevenue > 0 && (
                  <div className="h-8 w-full bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden mb-2">
                    <div 
                      className={`h-full ${totalProfit >= 0 ? 'bg-green-500' : 'bg-red-500'}`} 
                      style={{ width: `${Math.abs(totalProfit) / totalRevenue * 100}%` }}
                    ></div>
                  </div>
                )}
                
                <div className="flex justify-between text-sm">
                  <span className="flex items-center">
                    <span className="h-3 w-3 inline-block bg-gray-400 dark:bg-gray-500 rounded-full mr-1"></span>
                    Cost: ${totalCost.toFixed(2)}
                  </span>
                  <span className="flex items-center">
                    <span className={`h-3 w-3 inline-block ${totalProfit >= 0 ? 'bg-green-500' : 'bg-red-500'} rounded-full mr-1`}></span>
                    {totalProfit >= 0 ? 'Profit' : 'Loss'}: ${Math.abs(totalProfit).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
