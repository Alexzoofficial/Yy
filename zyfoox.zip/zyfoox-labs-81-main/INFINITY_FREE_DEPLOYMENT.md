
# Deploying to InfinityFree Hosting

This document provides step-by-step instructions for deploying this Zyfoox application to InfinityFree hosting.

## Preparation

1. First, build your application locally:
   ```
   npm run build
   ```

2. This will create a `dist` folder containing all the static files needed for your website.

## Uploading to InfinityFree

1. Login to your InfinityFree account and access the control panel

2. Navigate to the File Manager or use FTP software to connect to your hosting

3. Go to the `htdocs` folder - this is the root directory of your website

4. Upload all contents from your local `dist` folder directly into the `htdocs` folder

5. Make sure to include the `.htaccess` file from the public folder in your upload

## Important Notes for InfinityFree Hosting

1. **Favicon**: The favicon should now be visible in browser history. If it doesn't appear, make sure the file path in `index.html` is correct and the image file is properly uploaded.

2. **Client-Side Routing**: The .htaccess file is configured to handle client-side routing. If you experience 404 errors when navigating directly to routes, ensure the .htaccess file was properly uploaded.

3. **File Paths**: Ensure all file paths in your code use relative paths and not absolute paths for compatibility.

4. **Subdirectory Installation**: If you're installing in a subdirectory instead of the root htdocs folder, you'll need to adjust the base path in your application and .htaccess file.

5. **PHP Support**: This is a static site, but InfinityFree supports PHP if you need to add any server-side functionality later.

## Troubleshooting

- If images or assets don't load, check the paths in your HTML/CSS files
- If you get 404 errors for routes, verify the .htaccess file is in place
- Check that the favicon file exists at the path specified in index.html
- InfinityFree may have specific limitations or requirements - consult their documentation for hosting-specific issues

## Support

For additional assistance, refer to [InfinityFree's documentation](https://forum.infinityfree.net/docs) or contact their support team.
